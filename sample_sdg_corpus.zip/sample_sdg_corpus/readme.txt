This is a sample of the Story Dialog with Gesture Corpus. This sample contains two blog stories: a protest story and a storm story. Files include:

Original blog stories: “protest1_story.txt” and “storm1_story.txt”
Manually created dialogs: “protest1_dialog.txt” and “storm1_dialog.txt”
Gesture annotations: “protest1_gestures.docx” and “storm1_gestures.docx”
Narrative structure (Scheherazade) annotations: “protest1_scheherazade.vgl” and “storm1_scheherazade.vgl”